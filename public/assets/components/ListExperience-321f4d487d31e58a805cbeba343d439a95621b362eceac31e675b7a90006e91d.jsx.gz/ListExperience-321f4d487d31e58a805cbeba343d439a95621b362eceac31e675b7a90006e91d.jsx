class ListExperience extends React.Component{
  render(){
    return(
      <tr className="ListExperience">
        <td>{this.props.data.date_of_experience}</td>
      </tr>
    )
  }

}
